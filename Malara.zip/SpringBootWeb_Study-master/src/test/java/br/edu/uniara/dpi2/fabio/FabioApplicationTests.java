package br.edu.uniara.dpi2.fabio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FabioApplicationTests {

	@Test
	void contextLoads() {
	}

}

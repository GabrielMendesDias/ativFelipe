package br.edu.uniara.dpi2.fabio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FabioApplication {

	public static void main(String[] args) {
		SpringApplication.run(FabioApplication.class, args);
	}

}
